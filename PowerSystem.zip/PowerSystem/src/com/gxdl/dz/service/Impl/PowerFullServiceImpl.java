package com.gxdl.dz.service.Impl;

import java.math.BigDecimal;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gxdl.dz.controller.PowerFullController;
import com.gxdl.dz.dao.PowerFullMapper;
import com.gxdl.dz.po.UseConumer;
import com.gxdl.dz.po.UserMsgAndMoney;
import com.gxdl.dz.service.PowerFullService;
import com.gxdl.dz.service.UserInfoService;
import com.gxdl.dz.utils.RespouseUtil;

import net.sf.json.JSONObject;

@Service("powerFullService")
public class PowerFullServiceImpl implements PowerFullService {
	
	/**
	 * ��־���
	 */
	private Logger logger = LoggerFactory.getLogger(PowerFullController.class);
	
	@Autowired
	private PowerFullMapper powerFullMapper;
	@Autowired
	private UserInfoService userInfoService;

	/**
	 * ��ҳ����ص�ʱ���ȡ�û����ǳơ��˻�������ʣ���
	 */
	@Override
	public JSONObject getUserMsgAndMoney(String userToken) {
		JSONObject jsonObject = new JSONObject();
		try {
			if(userToken != null && userToken.length() > 0){
				UserMsgAndMoney userMsgAndMoney=this.powerFullMapper.getUserMsgAndMoney(userToken);
				if(userMsgAndMoney == null){
					jsonObject.put(RespouseUtil.SUCCESS_KRY, RespouseUtil.FAIL);
					logger.info("/UserInfoServiceImpl/getUserMsgAndMoney UserMsgAndMoney Object is NULL");
					return jsonObject;
				}
				jsonObject.put("userid",userMsgAndMoney.getUsedId());
				jsonObject.put("username",userMsgAndMoney.getUsername());
				jsonObject.put("accounts", userMsgAndMoney.getAccounts());
				jsonObject.put("surplusMoney", userMsgAndMoney.getSurplusMoney());
				jsonObject.put(RespouseUtil.SUCCESS_KRY, RespouseUtil.SUCCESS);
				return jsonObject;
			}else{
				jsonObject.put(RespouseUtil.SUCCESS_KRY, RespouseUtil.FAIL);
				logger.info("/UserInfoServiceImpl/getUserMsgAndMoney userToken is NULL");
				return jsonObject;
			}
		} catch (Exception e) {
			System.out.println("/UserInfoServiceImpl/getUserMsgAndMoney Exception : "+e.getMessage());
			logger.error("/UserInfoServiceImpl/getUserMsgAndMoney Exception:"+e.getMessage());
			return null;
		}
	}

	/**
	 * �û����˻����г�ֵ
	 * @param username
	 * @param accounts
	 * @param fullMoney
	 * @return
	 */
	@Override
	public JSONObject insertFullMoney(String userId,String username, String accounts, String fullMoney,String password) {
		JSONObject jsonObject = new JSONObject();
		try {
			if(username != null && password != null) {
				Map<String,String> map = this.userInfoService.verifyPassword(username, password);
				if(map == null || map.get(RespouseUtil.SUCCESS_KRY).equals(RespouseUtil.FAIL)) {
					jsonObject.put(RespouseUtil.SUCCESS_KRY, RespouseUtil.FAIL);
					return jsonObject;
				}
			}
			if(userId != null && accounts != null && fullMoney != null){
				UseConumer useConumer = this.powerFullMapper.getOriginalPowerMoney(userId, accounts);
				if(useConumer == null) {
					jsonObject.put(RespouseUtil.SUCCESS_KRY, RespouseUtil.FAIL);
					return jsonObject;
				}
				//�˴������ݴ�ϵͳ�������л��
			    BigDecimal param = new BigDecimal(0.5); 
			    BigDecimal fullMoneyDecimal = new BigDecimal(fullMoney); 
			    BigDecimal powerNumber = fullMoneyDecimal.divide(param,2,BigDecimal.ROUND_HALF_UP);
			    BigDecimal finalMoney = fullMoneyDecimal.add(useConumer.getSurplus_money());
			    BigDecimal finalpowerNumber=powerNumber.add(useConumer.getElectricitynumber());
				Integer result = this.powerFullMapper.insertFullMoney(userId,username, accounts, finalMoney.toString(),finalpowerNumber.toString());
				if(result <= 0) {
					jsonObject.put(RespouseUtil.SUCCESS_KRY, RespouseUtil.FAIL);
					System.out.println("/UserInfoServiceImpl/insertFullMoney "+username+" fullMoney not Successfaully");
					logger.error("/UserInfoServiceImpl/insertFullMoney "+username+" fullMoney not Successfaully");
					return jsonObject;
				}
				jsonObject.put(RespouseUtil.SUCCESS_KRY, RespouseUtil.SUCCESS);
				return jsonObject;
			}else{
				jsonObject.put(RespouseUtil.SUCCESS_KRY, RespouseUtil.FAIL);
				System.out.println("/UserInfoServiceImpl/insertFullMoney Exception Param value is NUll");
				logger.error("/UserInfoServiceImpl/insertFullMoney Exception Param value is NUll");
				return jsonObject;
			}
		} catch (Exception e) {
			jsonObject.put(RespouseUtil.SUCCESS_KRY, RespouseUtil.FAIL);
			System.out.println("/UserInfoServiceImpl/insertFullMoney Exception : "+e.getMessage());
			logger.error("/UserInfoServiceImpl/insertFullMoney Exception:"+e.getMessage());
			return jsonObject;
		}
	}
}
