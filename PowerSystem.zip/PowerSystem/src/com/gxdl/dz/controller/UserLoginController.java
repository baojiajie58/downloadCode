package com.gxdl.dz.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gxdl.dz.po.UserInfo;
import com.gxdl.dz.service.UserInfoService;
import com.gxdl.dz.utils.RespouseUtil;

import net.sf.json.JSONObject;

/**
 * ��ǰ��controller�������û���¼ע��ȴ���
 * @author Administrator
 *
 */
@Controller
@RequestMapping(value="/UserLoginController")
public class UserLoginController {
	
	@Autowired
	UserInfoService userInfoService;
	
	/**
	 * ��־���
	 */
	private Logger logger = LoggerFactory.getLogger(UserLoginController.class);
	
	/**
	 * У���û����Ƿ�Ψһ
	 * @param request
	 * @param response
	 * @param username
	 * @return
	 */
	@RequestMapping(value="/getUserNameOnly")
	public @ResponseBody String getUserNameOnly(HttpServletRequest request,HttpServletResponse response,String username){
		try {
			if(username != null && username.length() > 0){
				return this.userInfoService.getUserNameOnly(username);
			}else{
				return RespouseUtil.FAIL;
			}
		} catch (Exception e) {
			System.out.println("/UserLoginController/getUserNameOnly Exception:"+e.getMessage());
			logger.error("/UserLoginController/getUserNameOnly Exception:"+e.getMessage());
			return RespouseUtil.FAIL;
		}
	}
	
	/**
	 * �û�ע�������û�����Ϣ
	 * @param userInfo
	 * @return
	 */
	@RequestMapping("/addUserMassage")
	public @ResponseBody  String addUserMassage(String username,String mobile,
				  String emaile,String idnumber,String password,String yearday){
		try {
			//����ԭ������Ҫ��ÿ�����������жϵģ�ʱ��������ʦ��д�ˣ��������ǡ�
			return this.userInfoService.addUserMassage(username, mobile, emaile, idnumber, password, yearday);
		} catch (Exception e) {
			System.out.println("/UserLoginController/addUserMassage Exception:"+e.getMessage());
			logger.error("/UserLoginController/addUserMassage Exception:"+e.getMessage());
			return RespouseUtil.FAIL;
		}
	}
	
	/**
	 * �û���¼
	 * @param userInfo
	 * @return
	 */
	@RequestMapping("/userLoginSubmit")
	public @ResponseBody  JSONObject userLoginSubmit(HttpServletRequest request,String username,String password){
		//����һ��json��ʽ�Ķ���
		JSONObject jsonObject = new JSONObject();
		try {
			Map<String,Object> result = this.userInfoService.userLoginSubmit(username, password);
			if(result.size() <= 2){
				jsonObject.put(RespouseUtil.SUCCESS,result);
				return jsonObject;
			}
			UserInfo userinfo = (UserInfo) result.get("userinfo");
			request.getSession().setAttribute("userToken", userinfo.getUserToken());
			result.remove("userinfo");
			jsonObject.put(RespouseUtil.SUCCESS,result);
			return jsonObject;
		} catch (Exception e) {
			System.out.println("/UserLoginController/addUserMassage Exception:"+e.getMessage());
			logger.error("/UserLoginController/addUserMassage Exception:"+e.getMessage());
			jsonObject.put(RespouseUtil.FAIL,RespouseUtil.FAIL_Flag);
			return jsonObject;
		}
	}
	
	/**
	 * ��¼�ɹ��Ժ��ȡ�û�����
	 * @param userInfo
	 * @return
	 */
	@RequestMapping("/getUserName")
	public @ResponseBody  JSONObject getUserName(HttpServletRequest request,String userToken){
		//����һ��json��ʽ�Ķ���
		JSONObject jsonObject = new JSONObject();
		try {
			return this.userInfoService.getUserName(userToken);
		} catch (Exception e) {
			System.out.println("/UserLoginController/getUserName Exception:"+e.getMessage());
			logger.error("/UserLoginController/getUserName Exception:"+e.getMessage());
			jsonObject.put(RespouseUtil.SUCCESS_KRY,RespouseUtil.FAIL);
			return jsonObject;
		}
	}
}
