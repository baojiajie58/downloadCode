package com.gxdl.dz.pageController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gxdl.dz.jdbc.QueryBookJdbc;

@Controller
@RequestMapping(value="/PageAction")
public class PageAction {

	@RequestMapping(value="/toBookMassagePage")
	public String toBookMassagePage(HttpServletRequest request,HttpServletResponse response){
		String sql = "SELECT id,bookname,bookauthor,bookprice,bookprice,booksimple,booknumber FROM bookInfo LIMIT 0,10";
		List<Map> map = new QueryBookJdbc().QueryBookList(sql);
		Map currentPageMap = new HashMap<>();
		currentPageMap.put("currentPage", "1");
		map.add(currentPageMap);
		request.getSession().setAttribute("data",map);
		System.out.println(map.toString());
		return "bookMassage";
	}
}
